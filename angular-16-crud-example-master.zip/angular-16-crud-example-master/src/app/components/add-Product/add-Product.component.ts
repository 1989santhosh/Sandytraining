import { Component } from '@angular/core';
import { Product } from 'src/app/models/Product.model';
import { ProductService } from 'src/app/services/Product.service';

@Component({
  selector: 'app-add-Product',
  templateUrl: './add-Product.component.html',
  styleUrls: ['./add-Product.component.css'],
})
export class AddProductComponent {
  Product: Product = {
    name: '',
    description: '',
    published: false
  };
  submitted = false;

  constructor(private ProductService: ProductService) {}

  saveProduct(): void {
    const data = {
      Name: this.Product.name,
      description: this.Product.description
    };

    this.ProductService.create(data).subscribe({
      next: (res) => {
        console.log(res);
        this.submitted = true;
      },
      error: (e) => console.error(e)
    });
  }

  newProduct(): void {
    this.submitted = false;
    this.Product = {
      name: '',
      description: '',
      published: false
    };
  }
}
