import { Component, Input, OnInit } from '@angular/core';
import { ProductService } from 'src/app/services/Product.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Product } from 'src/app/models/Product.model';

@Component({
  selector: 'app-Product-details',
  templateUrl: './Product-details.component.html',
  styleUrls: ['./Product-details.component.css'],
})
export class ProductDetailsComponent implements OnInit {
  @Input() viewMode = false;

  @Input() currentProduct: Product = {
    name: '',
    description: '',
    published: false
  };

  message = '';

  constructor(
    private ProductService: ProductService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    if (!this.viewMode) {
      this.message = '';
      this.getProduct(this.route.snapshot.params['id']);
    }
  }

  getProduct(id: string): void {
    this.ProductService.get(id).subscribe({
      next: (data) => {
        this.currentProduct = data;
        console.log(data);
      },
      error: (e) => console.error(e)
    });
  }

  updatePublished(status: boolean): void {
    const data = {
      title: this.currentProduct.name,
      description: this.currentProduct.description,
      published: status
    };

    this.message = '';

    this.ProductService.update(this.currentProduct.id, data).subscribe({
      next: (res) => {
        console.log(res);
        this.currentProduct.published = status;
        this.message = res.message
          ? res.message
          : 'The status was updated successfully!';
      },
      error: (e) => console.error(e)
    });
  }

  updateProduct(): void {
    this.message = '';

    this.ProductService
      .update(this.currentProduct.id, this.currentProduct)
      .subscribe({
        next: (res) => {
          console.log(res);
          this.message = res.message
            ? res.message
            : 'This Product was updated successfully!';
        },
        error: (e) => console.error(e)
      });
  }

  deleteProduct(): void {
    this.ProductService.delete(this.currentProduct.id).subscribe({
      next: (res) => {
        console.log(res);
        this.router.navigate(['/Products']);
      },
      error: (e) => console.error(e)
    });
  }
}
