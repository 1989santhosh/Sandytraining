export class Product {
  id?: any;
  name?: string;
  description?: string;
  published?: boolean;
}