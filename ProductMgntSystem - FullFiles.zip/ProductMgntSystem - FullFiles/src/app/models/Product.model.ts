export class Product {
  id?: any;
  name?: string;
  description?: string;
  productCategory?:string;
  manufacturedDate?:Date;
  imageUrl?: string;
}