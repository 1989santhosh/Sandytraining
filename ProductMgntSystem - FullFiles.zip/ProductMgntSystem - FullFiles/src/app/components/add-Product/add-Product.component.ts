import { Component } from '@angular/core';
import { format } from 'date-fns';
import { Product } from 'src/app/models/Product.model';
import { ProductService } from 'src/app/services/Product.service';

@Component({
  selector: 'app-add-Product',
  templateUrl: './add-Product.component.html',
  styleUrls: ['./add-Product.component.css'],
})
export class AddProductComponent {
   Product = {
    name: '',
    description: '',
    productCategory:'',
    manufacturedDate: new Date()
  };
  submitted = false;
  selectedFile: File | null = null;
  constructor(private ProductService: ProductService) {   
   
  }

  onFileChange(event: Event) {
    const input = event.target as HTMLInputElement;
    if (input.files && input.files.length > 0) {
      this.selectedFile = input.files[0];
    }
  }


  saveProduct(): void {

    const formattedDate = this.Product.manufacturedDate ? format(this.Product.manufacturedDate, "yyyy-MM-dd'T'HH:mm:ss.SSSxxx") : null;
    const data = {
      ...this.Product,
      manufacturedDate: formattedDate
    };
    const formData = new FormData();
    formData.append('name', this.Product.name);
    formData.append('description', this.Product.description);
    formData.append('productCategory', this.Product.productCategory);
    formData.append('manufacturedDate', formattedDate!);
    
    if (this.selectedFile) {
      formData.append('productImage', this.selectedFile, this.selectedFile.name);
    }

    this.ProductService.create(formData).subscribe({
      next: (res) => {
        console.log(res);
        this.submitted = true;
      },
      error: (e) => console.error(e)
    });
  }

  newProduct(): void {
    this.submitted = false;
    this.Product = {
      name: '',
      description: '',
      productCategory: '',
      manufacturedDate: new Date()
    };
  }
}
